# Solution Docs

<!-- You can include documentation, additional setup instructions, notes etc. here -->

Additional features/improvements that could be done to the project:

1- Improve the overall styling of the component/input (css)

2- Add 'click outside' event to close the results list

3- Better handling of the results list in CSS, add some animations maybe

4- Overall clean up of the component's code base 
